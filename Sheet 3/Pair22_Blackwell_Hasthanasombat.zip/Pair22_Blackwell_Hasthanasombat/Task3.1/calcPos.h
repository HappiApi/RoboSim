void calcPosition(int leftEnc, int rightEnc);
